function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let seedX, seedY;
let plantado = false;
let colhido = false;

function setup() {
  createCanvas(600, 400);
  seedX = width / 2;
  seedY = height - 50;
}

function draw() {
  background(200, 255, 200);
  
  // Desenho do solo
  fill(139, 69, 19);
  rect(0, height - 50, width, 50);
  
  // Desenho da semente ou planta
  if (!plantado) {
    fill(255, 215, 0);
    ellipse(seedX, seedY, 20, 20); // Semente
  } else if (plantado && !colhido) {
    fill(34, 139, 34);
    rect(seedX - 10, seedY - 50, 20, 50); // Planta crescendo
  } else if (colhido) {
    fill(255, 0, 0);
    ellipse(seedX, seedY - 50, 30, 30); // Fruto colhido
  }
}

function mousePressed() {
  // Plantar a semente ao clicar na área
  if (dist(mouseX, mouseY, seedX, seedY) < 20 && !plantado) {
    plantado = true;
  }
  // Colher o fruto ao clicar na planta
  if (plantado && !colhido && mouseY < seedY - 25) {
    colhido = true;
  }
}